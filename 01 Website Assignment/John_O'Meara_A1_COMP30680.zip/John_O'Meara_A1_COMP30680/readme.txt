For my webpage, I've chosen a fansite layout for IDW publishings continuity of Transformers.

Homepage:	index.html
Gallery Page:	covers.html
3 other pages:	autobots.html
		decepticons.html
		idw.html

CSS:		\css\tf.css

Internal Links:	
		Navigation Bar
		Autobot & Decepticon Logos on Homepage
		Gallery cover links to full images

External Links:
		Individual Autobot & Decepticon names and images link to external IDW profiles on TFWiki
		IDW Publishing Header links to external IDW site

Navigation Bar:	
		On all pages

Table(s):	
		On autobots.html and on decepticons.html

list(s):	unordered list used in the navigation bar

Embedded video:
		Used on idw.html

CSS3 & HTML5 elements:
		in tf.css and in index.html

Css Positionl Properties:
		in tf.css - for the navigation bar and for the gallery

Inline & Block Elements:
		in tf.css for the navigation bar.



