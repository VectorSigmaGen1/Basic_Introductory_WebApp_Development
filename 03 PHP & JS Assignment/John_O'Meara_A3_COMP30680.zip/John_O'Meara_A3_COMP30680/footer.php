<?php
# Code adapted from supplied code from lectures
echo "<p>Copyright &copy; " . date("Y") . " Classic Models</p>";
?>