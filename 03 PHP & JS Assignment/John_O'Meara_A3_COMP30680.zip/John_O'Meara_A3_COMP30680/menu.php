<?php
echo '<ul id="navigation_bar">
        <li><a href="index.php">Home</a></li>
        <li><a href="customers.php">Customers</a></li>
        <li><a href="orders.php">Orders</a></li>
    </ul>'
?>